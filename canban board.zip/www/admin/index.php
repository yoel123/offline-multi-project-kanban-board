<?php
   include "../header.php";
   	//user validation
	/*if(!y_user::permission(5))
	{
		exit("your dont have permission to see this page");
	}*/
?>
<link href="../yapi/ajaxc/css/default.css" rel="stylesheet" type="text/css" media="screen">
<div class="admin_squer">
	<a href="cat.php">category</a>
</div><!--endf admin_squer-->
<div class="admin_squer">
	<a href="posts.php">posts</a>
</div><!--endf admin_squer-->
<div class="admin_squer">
	<a href="site_config.php">site config </a>
</div><!--endf admin_squer-->
